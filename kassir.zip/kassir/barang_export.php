<?php

include 'config.php';

if(isset($_POST["submit"]))
{
    $query = "SELECT * FROM barang where qoldiq > 0";
//    $query = "SELECT transaksi_detall.*, transaksi.*, barang.nama, barang.id_barang, barang.qoldiq FROM `transaksi_detall`, `transaksi`, `barang` WHERE transaksi_detall.id_transaksi = transaksi.id_transaksi AND transaksi_detall.id_barang = barang.id_barang AND transaksi.tanggal_waktu BETWEEN '".$_POST["from_date"]."' AND '".$_POST["to_date"]."'";

    $res = mysqli_query($dbconnect, $query);
    if(mysqli_num_rows($res) > 0)
    {


        $export .= '
 <table border="1"> 
 <tr>
            <th>ID</th>
            <th>Товар</th>
            <th>Цена в приходе</th>
            <th>Цена в продаже</th>
            <th>Количество на складе</th>
            <th>Дата</th>
            <th>Остатка</th>
          
        </tr>

 ';

        while($row = mysqli_fetch_array($res))
        {
            $export .= '
 <tr>           
                <td>'.$row["id_barang"].'</td>
                <td>'.$row["nama"].'</td>
                <td>'.$row["harga_k"].'</td>
                <td style="background-color: yellow">'.$row["harga"].'</td>
                <td>'.$row["jumlah"].'</td>
                <td>'.$row["dates"].'</td>
                <td style="background-color: yellow">'.$row["qoldiq"].'</td>
 
 </tr>
 ';
        }
        $export .= '</table>';
        header('Content-Type: application/xls');
        header('Content-Disposition: attachment; filename=info.xls');
        echo $export;
    }
}



?>

<meta charset="utf-8">
