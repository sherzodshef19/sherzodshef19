<?php
include 'config.php';
session_start();
//include 'authcheck.php';

if(isset($_POST['simpan'])){

    $kode_barang = $_POST['kode_barang'];
    $nama = $_POST['nama'];
    $harga_k = $_POST['harga_k'];
    $harga = $_POST['harga'];
    $jumlah = $_POST['jumlah'];
    $date = $_POST['dates'];

    mysqli_query($dbconnect, "INSERT INTO `barang` (`id_barang`, `nama`, `harga_k`, `harga`, `jumlah`, `dates`, `kode_barang`) VALUE ('', '$nama', '$harga_k', '$harga', '$jumlah', '$date', '$kode_barang')");
    $_SESSION['success'] = 'Товар добавлено!';

    header("location:barang.php");
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <link rel="stylesheet" href="doc/css/bootstrap.css">
    <script src="doc/js/bootstrap.js"></script>
    <script src="doc/js/jquery.min.js"></script>
</head>
<body>


<div class="container">
    <h1>Добавить товар</h1>

    <form method="post">
        <div class="form-group">
            <label>Штрих код</label>
            <input type="text" name="kode_barang" class="form-control" placeholder="Штрих">
        </div>
        <div class="form-group">
            <label>Название товара</label>
            <input type="text" name="nama" class="form-control" placeholder="Товар">
        </div>
        <div class="form-group">
            <label>Цена в приходе</label>
            <input type="number" name="harga_k" class="form-control" placeholder="Цена в приходе">
        </div>

        <div class="form-group">
            <label>Цена в продаже</label>
            <input type="number" name="harga" class="form-control" placeholder="Цена в продаже">
        </div>

        <div class="form-group">
            <label>Кол-во</label>
            <input type="number" name="jumlah" class="form-control" placeholder="Кол-во">
        </div>

        <div class="form-group">
            <label>Дата</label>
            <input type="datetime-local" name="dates" class="form-control" placeholder="Дата">
        </div>

        <input type="submit" name="simpan" value="Добавить" class="btn btn-primary">
        <a href="barang.php" class="btn btn-warning">Вернуть</a>



    </form>
</div>



</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $(window).keydown(function(event){
            if(event.keyCode == 13) {
                event.preventDefault();
                return false;
            }
        });
    });
</script>
</html>

