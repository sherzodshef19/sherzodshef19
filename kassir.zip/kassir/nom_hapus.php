<?php

include 'config.php';
session_start();
include 'authcheck.php';
if(isset($_GET['id'])){

    $id = $_GET['id'];

    mysqli_query($dbconnect, "DELETE FROM `nomenklatura` WHERE id_nomenklatura='$id'");
    $_SESSION['success'] = 'Удалено!!!';
    header("Location: nomenklatura.php");
}


?>

