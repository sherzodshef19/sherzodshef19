<?php

include 'config.php';

if(isset($_POST["submit"]))
{
    $query = "SELECT transaksi_detall.*, transaksi.*, barang.nama, barang.id_barang, barang.qoldiq FROM `transaksi_detall`, `transaksi`, `barang` WHERE transaksi_detall.id_transaksi = transaksi.id_transaksi AND transaksi_detall.id_barang = barang.id_barang ORDER BY `transaksi`.`tanggal_waktu` ASC";
//    $query = "SELECT transaksi_detall.*, transaksi.*, barang.nama, barang.id_barang, barang.qoldiq FROM `transaksi_detall`, `transaksi`, `barang` WHERE transaksi_detall.id_transaksi = transaksi.id_transaksi AND transaksi_detall.id_barang = barang.id_barang AND transaksi.tanggal_waktu BETWEEN '".$_POST["from_date"]."' AND '".$_POST["to_date"]."'";

    $res = mysqli_query($dbconnect, $query);
    if(mysqli_num_rows($res) > 0)
    {


        $export .= '
 <table> 
 <tr>
            <th>ID</th>
            <th>Товар</th>
            <th>Дата</th>
            <th>штук</th>
            <th>Цена в продаже</th>
            <th>Остатка</th>
            <th>Итого</th>
            <th>всего</th>
            <th>Какой</th>
            <th>Сотрудник</th>
        </tr>

 ';

        while($row = mysqli_fetch_array($res))
        {
            $export .= '
 <tr>           
                <td>'.$row["monor"].'</td>
                <td>'.$row["nama"].'</td>
                <td>'.$row["tanggal_waktu"].'</td>
                <td>'.$row["qrt"].'</td>
                <td>'.$row["harga"].'</td>
                <td>'.$row["qoldiq"].'</td>
                <td>'.($row["qrt"]*$row["harga"]).'</td>
                <td>'.$row["total"].'</td>
                <td>'.$row["stol"].'</td>
                <td>'.$row["xodim_name"].'</td>
                <td>'.$row[""].'</td>
 
 </tr>
 ';
        }
        $export .= '</table>';
        header('Content-Type: application/xls');
        header('Content-Disposition: attachment; filename=info.xls');
        echo $export;
    }
}



?>

<meta charset="utf-8">
