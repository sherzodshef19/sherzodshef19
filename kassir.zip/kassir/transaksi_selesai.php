<?php
include 'config.php';
session_start();
include 'authcheckkassir.php';
$id_trx = $_GET['idtrx'];

$data = mysqli_query($dbconnect, "SELECT * FROM transaksi WHERE id_transaksi='$id_trx'");

$trx = mysqli_fetch_assoc($data);
$detail = mysqli_query($dbconnect, "SELECT transaksi_detall.*, barang.* FROM `transaksi_detall` INNER JOIN barang ON transaksi_detall.id_barang=barang.id_barang WHERE transaksi_detall.id_transaksi='$id_trx'");
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Kassir</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"
          integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <link rel="stylesheet" href="doc/css/bootstrap.css">
    <script src="doc/js/bootstrap.js"></script>
    <script src="doc/js/jquery.min.js"></script>

    <style>
        body{
            width: 220px;
            padding: 5px;
        }
        @media print {
            #printPageButton {
                display: none;
            }
        }
    </style>

</head>



<body onafterprint="myFunction()">
<!--<button type="button" class="fa fa-home btn btn-success" onclick="location.href='kassir.php'"></button></td>-->
<!--<button type="button" class="fa fa-print btn btn-danger" onclick="window.print()"></button></td>-->


<div align="left">

    <table width="200" border="0" cellpadding="1" cellspacing="0">

        <tr align="center">
            <th style="text-align: center; font-family: "Helvetica Neue", Helvetica, Arial, sans-serif">ORGTEX
            </th>
        </tr>
        <tr align="center">
        </tr>
        <tr>
            <th style="font-size: 12px; text-align: center">#<?=$trx['monor']?> | <?=

                date("Y-m-d | H:i:s", strtotime($trx['tanggal_waktu'])); ?> <br/>Сотрудник: </i> <?=$trx['xodim_name']?></i> <br/><?=$trx['stol']?></th></tr>
    </table>

    <table width="200" border="1" cellspacing="0" cellpadding="3">

        <?php
        while ($row = mysqli_fetch_array($detail)){ ?>

            <tr style="font-size: 12px">
                <td><?=$row['nama']?></td>
                <td><?=$row['qrt']?></td>
                <td align="right"><?=number_format($row['harga'])?></td>
                <td align="right" style="padding-left: 0px"><?=number_format($row['total'])?></td>
            </tr>


        <?php }
        ?>

        </tr>

        <tr style="font-size: 12px">
            <td align="right" colspan="3">Сумма</td>
            <td align="right" style="padding-left: 0px"><?=number_format($trx['total'])?></td>
        </tr>

        <tr>
            <td align="right" colspan="3" style="font-size: 12px">Оплачено</td>
            <td align="right" style="font-size: 12px; padding-left: 0px"><?=number_format($trx['bayar'])?></td>
        </tr>

        <tr>
            <td align="right" colspan="3" style="font-size: 12px">Сдача</td>
            <td style="font-size: 12px; padding-left: 0px" align="right"><?=number_format($trx['kemball'])?></td>
        </tr>
    </table>

    <table width="200" border="0" cellpadding="0" cellspacing="0" style="font-size: 12px">

        <tr><td style="text-align: center;">«СПАСИБО, что Вы с нами»</td></tr>
    </table>
    <tr><br><br>. <br><br></tr>

    <button id="printPageButton" class="btn btn-danger" onclick="window.location.href='/kassir.php'">Назад</button>
</div>

</body>
<script type="text/javascript">
    $(document).ready(function (){
        window.print();
    });

</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</html>