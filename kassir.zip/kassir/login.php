<?php
include 'config.php';
session_start();
//print_r($_SESSION);
if(isset($_POST['masuk'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = mysqli_query($dbconnect, "SELECT * FROM user WHERE username='$username' and password='$password'");

    $data = mysqli_fetch_assoc($query);

    $check = mysqli_num_rows($query);

    if (!$check) {
        $_SESSION['error'] = 'Username & password salah';
    } else {
        $_SESSION['userid'] = $data['id_user'];
        $_SESSION['nama'] = $data['nama'];
        $_SESSION['role_id'] = $data['role_id'];
//        $_SESSION['auth'] = 'Yes';


        header("Location:index.php");
    }

}
?>


<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"
          integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

    <link rel="stylesheet" href="doc/css/bootstrap.css">
    <script src="doc/js/bootstrap.js"></script>
    <script src="doc/js/jquery.min.js"></script>
</head>
<style>
    body{
        background: url("/image/back2.png");
        background-position: center;
        background-size: cover;
        background-attachment: fixed;
        background-repeat: no-repeat;
    }
   .container form label{
        color: white;
       margin-top: 20px;
       font-size: 20px;

    }
   .container form .form-group input{
       font-size: 20px;
       padding: 20px;
   }
    .container form{
        margin-top: 20%;
    }
</style>
<body>


<div class="container">


    <?php
    if (isset($_SESSION['error']) && $_SESSION['error'] != '') {
        ?>

        <div class="alert alert-danger" role="alert">
            <?= $_SESSION['error'] ?>
        </div>

    <?php }
    $_SESSION['error'] = '';

    ?>

    <form method="post" class="col-md-12" style="margin: 0 auto;">
        <h1 align="center" style="color: white;">LOGIN</h1>

        <div class="form-group">
            <label for="exampleInputEmail1">Username</label>
            <input type="text" class="form-control" name="username" placeholder="Username">
        </div>


        <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" class="form-control" name="password" placeholder="Password">
        </div>

        <input type="submit" name="masuk" value="Войти" class="btn btn-info btn-lg" style="margin-top: 2%">
    </form>




</div>


</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</html>
