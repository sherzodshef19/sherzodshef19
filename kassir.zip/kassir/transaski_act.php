<?php
include 'config.php';
session_start();
include 'authcheckkassir.php';
date_default_timezone_set('Asia/Tashkent');

$bayar = preg_replace('/\D/', '', $_POST['bayar']);

//$tanggal_waktu = date('Y-m-d H:i:s');
$tanggal_waktu = $_POST['datenow'];
$monor = rand(111111, 999999);
$total = $_POST['total'];
$stol = $_POST['stol'];
$xodim = $_POST['xodim_nomi'];
$nama = $_SESSION['nama'];
$kemball = $bayar - $total;



mysqli_query($dbconnect, "INSERT INTO transaksi (id_transaksi, tanggal_waktu, monor, total, nama, bayar, kemball, stol, xodim_name) VALUE (NULL, '$tanggal_waktu', '$monor', '$total', '$nama', '$bayar', '$kemball', '$stol', '$xodim')");

$id_transaksi = mysqli_insert_id($dbconnect);

foreach ($_SESSION['cart'] as $key => $value){
    $id_barang = $value['id'];
    $harga = $value['harga'];
    $qty = $value['qty'];
    $tot = $harga*$qty;
    mysqli_query($dbconnect, "INSERT INTO transaksi_detall(id_transaksi_detail, id_transaksi, id_barang, harga, qrt, total) VALUE (NULL, '$id_transaksi', '$id_barang', '$harga', '$qty', '$tot')");
}
$_SESSION['cart'] = [];
header("location:transaksi_selesai.php?idtrx=".$id_transaksi);

?>
