<?php
session_start();

if(isset($_SESSION['userid']))
{
    if($_SESSION['role_id']==2)
    {
        header("location:kassir.php");
    }
}else{
    $_SESSION['error'] = 'Ошибка!';
    header("location:login.php");
}

?>
