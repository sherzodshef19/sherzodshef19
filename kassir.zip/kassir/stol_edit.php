<?php
include 'config.php';
session_start();
include 'authcheck.php';
if(isset($_GET['id'])){
    $id = $_GET['id'];

    $data = mysqli_query($dbconnect, "SELECT * FROM stol where id_stol='$id'");
    $data = mysqli_fetch_assoc($data);
}

if(isset($_POST['update'])){
    $id = $_GET['id'];
    $stol_name = $_POST['stol_name'];


    mysqli_query($dbconnect, "UPDATE stol SET stol_name='$stol_name' where id_stol='$id'");
    header("Location:stol.php");
}


?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Обновлять</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <link rel="stylesheet" href="doc/css/bootstrap.css">
    <script src="doc/js/bootstrap.js"></script>
    <script src="doc/js/jquery.min.js"></script>
</head>
<body>


<div class="container">
    <h1>Обновлять</h1>
    <form method="post">
        <div class="form-group">
            <label>Назавание</label>
            <input type="text" name="stol_name" class="form-control" placeholder="Название" value="<?=$data['stol_name']?>">
        </div>



        <input type="submit" name="update" value="Обновлять" class="btn btn-primary">
        <a href="/stol.php" class="btn btn-warning">Вернуть</a>



    </form>
</div>



</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
</html>

