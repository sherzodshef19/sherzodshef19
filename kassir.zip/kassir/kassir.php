<?php
include 'config.php';
session_start();
include 'authcheckkassir.php';

$barang = mysqli_query($dbconnect, "SELECT * FROM barang");
$kurs_dollar = mysqli_query($dbconnect, "SELECT * FROM kollar");
$stol = mysqli_query($dbconnect, "SELECT * FROM stol");
$xodim_nomi = mysqli_query($dbconnect, "SELECT * FROM xodim");



$allowed = mysqli_query($dbconnect,"UPDATE barang
SET qoldiq = (SELECT t1.remainds
              FROM (SELECT barang.id_barang, (barang.jumlah - IFNULL(transaksi_detall.sold, 0)) as remainds
                    FROM barang
                             LEFT JOIN (
                        SELECT id_barang, SUM(qrt) as sold FROM transaksi_detall GROUP BY id_barang) as transaksi_detall
                                       ON barang.id_barang = transaksi_detall.id_barang) as t1
              WHERE t1.id_barang = barang.id_barang)
WHERE barang.id_barang IS NOT NULL;");

$sum = 0;
if (isset($_SESSION['cart'])) {



    foreach ($_SESSION['cart'] as $key => $value) {
        $sum += $value['harga']*$value['qty'];


    }
}

?>


<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Kassir</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"
          integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <link rel="stylesheet" href="doc/css/bootstrap.css">
    <script src="doc/js/bootstrap.js"></script>
    <script src="doc/js/jquery.min.js"></script>
</head>
<style>
    body{
        font-size: 30px;
    }
</style>
<body>


<div class="container-fluid">

    <div class="row">
        <div class="col-md-6">
            <h3>Привет</h3>
            <h4>Пользователь: <?= $_SESSION['nama'] ?></h4>
            <a class="btn btn-danger" href="keranjang_reset.php">Новый</a>
            <a class="btn btn-success" href="riwayat.php" target="_blank"> Чеки</a>
            <a class="btn btn-primary" href="history.php" target="_blank"> История по одной</a>
            <a class="btn btn-info" href="price.php" target="_blank"> Цены</a>
            <a class="btn btn-warning" href="logout.php"> Выйти</a>
        </div>
        <form class="col-md-1" style="text-align: center">
            <?php
            while($data = $kurs_dollar->fetch_array()) {?>
            <label style="font-size: 15px; text-align: center;">Курс $</label>
            <input type="hidden" value="<?=$data['id_kurs']?>">
            <input type="text" class="form-control" name="kurs_dollar" value="<?=$data['kurs_dollar']?>" disabled style="font-size: 20px; text-align: center">
            <a href="/kurs_dollar.php?id=<?=$data['id_kurs']?>" class="form-control btn btn-primary">изменить</a>
        </form>
<?php } ?>
        <?php

        $kurs_dollar = mysqli_query($dbconnect, "SELECT * FROM kollar");


        $result = mysqli_fetch_array($kurs_dollar);
        $sum_d = $result['kurs_dollar'];
        ?>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-8">
            <form method="post" action="keranjang_act.php" class="form-inline">
<!--                <div class="input-group">-->
<!--                    <select name="id_barang" class="form-control">-->
<!--                        <option>Выбрать</option>-->
<!--                        --><?php //while ($row = mysqli_fetch_array($barang)) { ?>
<!--                            <option value="--><?//= $row['id_barang'] ?><!--">--><?//= $row['nama'] ?><!--</option>-->
<!--                        --><?php //} ?>
<!---->
<!--                    </select>-->
<!--                </div>-->
<!---->
<!--                <div class="input-group">-->
<!--                    <input type="number" name="qty" class="form-control" placeholder="Кол-во">-->
<!--                    <span class="input-group-btn">-->
<!--                        <button class="btn btn-primary" type="submit"><i class="fa fa-plus"></i> Добавить </button>-->
<!--                    </span>-->
<!--                </div>-->

                <div class="form-group">
                    <input type="text" name="kode_barang" tabindex="1" class="form-control" placeholder="Товары Штрих код" style=" font-size: 20px; padding: 15px 18px" autofocus>
                </div>

<!--                <div class="input-group">-->
<!--                                        <input type="number" name="qty" class="form-control" placeholder="Кол-во">-->
<!--                                        <span class="input-group-btn">-->
<!--                                            <button class="btn btn-primary" type="submit"><i class="fa fa-plus"></i> Добавить </button>-->
<!--                                        </span>-->
<!--                                    </div>-->
            </form>

            <br/>
            <form action="keranjang_update.php" method="post">
                <table class="table table-bordered">

                    <tr>
                        <th>Название товара</th>
                        <th>Цена </th>
                        <th>Кол-во</th>
                        <th>Остатка</th>
                        <th>Итого</th>
                        <th></th>
                    </tr>
                    <?php if(isset($_SESSION['cart'])): ?>
                    <?php foreach ($_SESSION['cart'] as $key => $value) {
                        ?>


                            <tr>
                                                            <td><?= $value['nama'] ?></td>
<!--                            <td align="right">--><?//= number_format($value['harga']) ?><!--</td>-->
<td class="col-md-2"><input type="number" class="form-control" name="harga[]" value="<?= $value['harga'] ?>" style="font-size: 30px"></td>
<td class="col-md-2"><input type="number" class="form-control" name="qty[]" value="<?= $value['qty'] ?>" style="font-size: 30px"></td>
                            <td style="background: yellow"><?= $value['qoldiq'] ?></td>

                            <td align="right"><?= number_format($value['qty'] * $value['harga']) ?></td>
 <td><a href="keranjang_hapus.php?id=<?= $value['id'] ?>" class="btn btn-danger"><i
                                            class="glyphicon glyphicon-remove"></i></a>
                           </td>
                        </tr>


                    <?php } ?>
                    <?php endif; ?>


                </table>
                <button type="submit" class="btn btn-success">Обновлять</button>
            </form>
        </div>
        <div class="col-md-3">

            <h1>Всего <i style="background: yellow"><?= number_format($sum, '0', '.', ' ')?></i> сум<br/>
                <br>
            <i style="background: yellow; margin-left: 104px"><?= number_format(($sum/$sum_d), 2, '.', ' ') ?></i> $</h1>
            <form action="transaski_act.php" method="post">
                <input type="hidden" name="total" value="<?=$sum?>">
                <div class="form-group">
                    <select name="stol" id="stol" class="form-control" style="width: 50%">
                        <?php while ($row = $stol->fetch_array()) { ?>

                            <option value="<?=$row['stol_name'];?>"><?=$row['stol_name'];?></option>
                        <?php }?>

                    </select>
                    <label>Оплачено</label>
                    <input type="text" id="bayar" name="bayar" class="form-control" style="font-size: 30px; padding: 20px 25px; width: 50%" placeholder="сумма">
                </div>
                <input type="datetime-local" class="form-control" name="datenow" id="today" style="padding: 20px 25px; width: 70%; margin-bottom: 3%" required>
                <select name="xodim_nomi" id="xodim_nomi" class="form-control" style="width: 50%">
                    <?php while ($row = $xodim_nomi->fetch_array()) { ?>

                        <option value="<?=$row['xodim_nomi'];?>"><?=$row['xodim_nomi'];?></option>
                    <?php }?>

                </select>
                <button type="submit" class="btn btn-primary">Готово</button>
            </form>
        </div>
    </div>

</div>


</body>
<script type="text/javascript">

    var bayar = document.getElementById('bayar');


    bayar.addEventListener('keyup', function (e) {
        bayar.value = formatRupiah(this.value, 'Сум. ');

    });

    function formatRupiah(angka, prefix) {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split = number_string.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            rubuan = split[0].substr(sisa).match(/\d{3}/gi);

        if (rubuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + rupiah.join('.');
        }
        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Сум. ' + rupiah : '');
    }

    function cleanRupiah(rupiah) {
        var clean = rupiah.replace(/\D/g, '');
        return clean;
    }

</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</html>