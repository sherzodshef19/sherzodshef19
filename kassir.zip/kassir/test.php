<?php
include 'config.php';
session_start();
$id_trx = $_GET['idtrx'];

$data = mysqli_query($dbconnect, "SELECT * FROM transaksi WHERE id_transaksi='$id_trx'");

$trx = mysqli_fetch_assoc($data);

$detail = mysqli_query($dbconnect, "SELECT transaksi_detall.*, barang.nama FROM `transaksi_detall` INNER JOIN barang ON transaksi_detall.id_barang=barang.id_barang WHERE transaksi_detall.id_transaksi='$id_trx'");

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<table border="1">

    <?php
    while ($row = mysqli_fetch_array($detail)){ ?>

        <tr>
            <td><?=$row['nama']?></td>
            <td><?=$row['qrt']?></td>
            <td align="right"><?=number_format($row['harga'])?></td>
            <td align="right"><?=number_format($row['total'])?></td>
        </tr>


    <?php }
    ?>




</table>


</body>
</html>
