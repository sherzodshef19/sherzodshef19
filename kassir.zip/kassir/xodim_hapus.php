<?php

include 'config.php';
session_start();
include 'authcheck.php';
if(isset($_GET['id'])){
    $id = $_GET['id'];

    mysqli_query($dbconnect, "DELETE FROM `xodim` WHERE id_xodim='$id'");
    $_SESSION['success'] = 'Удалено!!!';
    header("Location:xodim.php");
}


?>

