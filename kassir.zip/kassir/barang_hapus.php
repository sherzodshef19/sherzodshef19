<?php

include 'config.php';
session_start();
if(isset($_GET['id'])){
    $id = $_GET['id'];

    mysqli_query($dbconnect, "DELETE FROM `barang` WHERE id_barang='$id'");
    $_SESSION['success'] = 'Удалено!!!';
    header("Location:barang.php");
}


?>

