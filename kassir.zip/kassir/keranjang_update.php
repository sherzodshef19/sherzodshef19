<?php
include 'config.php';
session_start();
include 'authcheckkassir.php';

$qty = $_POST['qty'];
$harga = $_POST['harga'];

foreach ($_SESSION['cart'] as $key => $value) {

    $_SESSION['cart'][$key]['qty'] = $qty[$key];
    $_SESSION['cart'][$key]['harga'] = $harga[$key];
}
header("location:kassir.php");

?>