<?php
include_once("inc/db_connect.php");

$query = "SELECT transaksi_detall.*, transaksi.*, barang.nama, barang.id_barang, barang.qoldiq FROM `transaksi_detall`, `transaksi`, `barang` WHERE transaksi_detall.id_transaksi = transaksi.id_transaksi AND transaksi_detall.id_barang = barang.id_barang ORDER BY `transaksi`.`tanggal_waktu` ASC";
$results = mysqli_query($conn, $query) or die("database error:". mysqli_error($conn));
$allOrders = array();

while( $order = mysqli_fetch_assoc($results) ) {
	$allOrders[] = $order;
}
$startDateMessage = '';
$endDate = '';
$noResult ='';
if(isset($_POST["export"])){
 if(empty($_POST["fromDate"])){
  $startDateMessage = '<label class="text-danger">Select start date.</label>';
 }else if(empty($_POST["toDate"])){
  $endDate = '<label class="text-danger">Select end date.</label>';
 } else {  
  $orderQuery = "
	SELECT transaksi_detall.*, transaksi.*, barang.nama, barang.id_barang, barang.qoldiq FROM `transaksi_detall`, `transaksi`, `barang`	WHERE transaksi_detall.id_transaksi = transaksi.id_transaksi AND transaksi_detall.id_barang = barang.id_barang AND `transaksi`.`tanggal_waktu` >= '".$_POST["fromDate"]."' AND `transaksi`.`tanggal_waktu` <= '".$_POST["toDate"]."'";
  $orderResult = mysqli_query($conn, $orderQuery) or die("database error:". mysqli_error($conn));
  $filterOrders = array();
  while( $order = mysqli_fetch_assoc($orderResult) ) {
	$filterOrders[] = $order;
  }
  if(count($filterOrders)) {
	  $fileName = 'Order Data.csv';
      header('Content-Type: text/csv; charset=UTF-8');
	  header("Content-Description: File Transfer");
      header("Content-Disposition: attachment; filename=$fileName");
	  header("Content-Type: application/csv;");
      header('Content-Encoding: UTF-8');
      header('Content-type: text/csv; charset=UTF-8');
      $order = iconv('UTF-8', 'UTF-8', $order);


      $file = fopen('php://output', 'w');
	  $header = array("Id", "Товар", "Дата", "штук", "Цена в продаже", "Итого", "Остатка", "Какой", "Сотрудник");
	  fputcsv($file, $header);
      foreach($filterOrders as $order)
      {

          $orderData = array();
	   $orderData[] = $order["monor"];
	   $orderData[] = $order["nama"];
	   $orderData[] = $order["tanggal_waktu"];
	   $orderData[] = $order["qrt"];
	   $orderData[] = $order["harga"];
	   $orderData[] = $order["qoldiq"];
	   $orderData[] = ($order["qrt"]*$order["harga"]);
	   $orderData[] = $order["total"];
	   $orderData[] = $order["stol"];
	   $orderData[] = $order["xodim_name"];
	   fputcsv($file, $orderData);
	  }
	  fclose($file);
	  exit;
  } else {
	 $noResult = '<label class="text-danger">((((((())))))))))))))</label>';
  }
 }
}
?>

<meta charset="UTF-8">
