<?php
$host = "192.168.1.8";

// $host = "localhost";
$user = "root";
$pass = "";
$db = "kassir";

$dbconnect = new mysqli("$host", "$user", "$pass", "$db");

if($dbconnect-> connect_error)
{
    echo "Kok -> " . $dbconnect->connect_error;
}
?>
