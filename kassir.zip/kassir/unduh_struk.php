<?php
session_start();
require_once 'library/dompdf/autoload.inc.php';

$id_trx = $_GET['idtrx'];
use Dompdf\Dompdf;

$dompdf = new Dompdf('P','mm','A4',true,'UTF-8',false);

ob_start();
require 'transaksi_selesai_pdf.php';
$ruk = ob_get_clean();
ob_get_clean();


$dompdf->loadHtml($ruk,'UTF-8');
$dompdf->setPaper('a4', 'potrait');
$dompdf->render();
$dompdf->stream('Invoice #'.$trx['monor'].'pdf', ["Attachment" => false]);
exit(0);
?>
<style>
    body{
        padding: 0;
        margin: 0;
    }
</style>
