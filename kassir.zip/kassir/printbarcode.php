<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

        <table align="center" border="1" cellpadding="3" cellspacing="1">
                <?php for($i=0; $i<10; $i++): ?>

                    <tr>
                        <td>
                            <img src="/library/barcode.php?text=<?='barang-'.$i.'1'?>&print=true" alt="<?='barang-'.$i.'1'?>" />
                        </td>
                        <td>
                            <img src="/library/barcode.php?text=<?='barang-'.$i.'2'?>&print=true" alt="<?='barang-'.$i.'2'?>" />
                        </td>
                        <td>
                            <img src="/library/barcode.php?text=<?='barang-'.$i.'3'?>&print=true" alt="<?='barang-'.$i.'3'?>" />
                        </td>
                    </tr>

                <?php endfor; ?>
        </table>

</body>
</html>