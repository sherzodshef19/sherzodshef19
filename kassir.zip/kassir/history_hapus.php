<?php

include 'config.php';
session_start();
if(isset($_GET['id'])){
    $id = $_GET['id'];

    mysqli_query($dbconnect, "DELETE FROM `transaksi_detall` WHERE id_transaksi_detail='$id'");
    $_SESSION['success'] = 'Удалено!!!';
    header("Location:history.php");
}


?>

