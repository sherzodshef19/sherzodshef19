<?php
include 'config.php';
include "authcheckkassir.php";


$data = mysqli_query($dbconnect, "SELECT * FROM transaksi WHERE id_transaksi='$id_trx'");

$trx = mysqli_fetch_assoc($data);

$detail = mysqli_query($dbconnect, "SELECT transaksi_detall.*, barang.nama FROM `transaksi_detall` INNER JOIN barang ON transaksi_detall.id_barang=barang.id_barang WHERE transaksi_detall.id_transaksi='$id_trx'");



?>

<!doctype html>
<html>
<head>
</head>
<style>
    *{
        padding: 0;
        margin: 0;
    }
    body{
        width: 220px;
        padding: 0px;
        font-family: "DejaVu Sans";
    }
</style>
<body>


<div align="left">

    <table width="130" border="0" cellpadding="1" cellspacing="0">

        <tr align="center">
            <th style="text-align: center"><p>ORGTEX</p>
            </th>
        </tr>
        <tr>
            <th style="font-size: 10px; text-align: center">#<?=$trx['monor']?> | <?=date('d-m-Y H:i:s'."", strtotime($trx['tanggal_waktu']));?> <i class="fa fa-user"><br/>Сотрудник: </i> <?=$trx['nama']?> <br/><?=$trx['stol']?></th></tr>


    </table>

    <table width="130" border="1" cellspacing="0" cellpadding="3">

        <?php
        while ($row = mysqli_fetch_array($detail)){ ?>

            <tr style="font-size: 10px">
                <td><?=$row['nama']?></td>
                <td><?=$row['qrt']?></td>
                <td align="right"><?=number_format($row['harga'])?></td>
                <td align="right"><?=number_format($row['total'])?></td>
            </tr>


        <?php }
        ?>

        </tr>

        <tr style="font-size: 10px">
            <td align="right" colspan="3">Сумма</td>
            <td align="right"><?=number_format($trx['total'])?></td>
        </tr>

        <tr>
            <td align="right" colspan="3" style="font-size: 12px">Оплачено</td>
            <td align="right" style="font-size: 12px"><?=number_format($trx['bayar'])?></td>
        </tr>

        <tr>
            <td align="right" colspan="3" style="font-size: 12px">Сдача</td>
            <td style="font-size: 12px" align="right"><?=number_format($trx['kemball'])?></td>
        </tr>
    </table>

    <table width="130" border="0" cellpadding="0" cellspacing="0" style="font-size: 12px">


        <tr><td style="text-align: center;">«СПАСИБО, что Вы с нами»</td></tr>
        <tr><br><br>. <br><br></tr>
    </table>

</div>

</body>
</html>