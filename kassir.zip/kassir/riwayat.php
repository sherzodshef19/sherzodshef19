<?php
include 'config.php';
session_start();

include 'authcheckkassir.php';

$view = $dbconnect->query("SELECT * FROM transaksi");

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>История</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <link rel="stylesheet" href="doc/css/bootstrap.css">
    <script src="doc/js/bootstrap.js"></script>
    <script src="doc/js/jquery.min.js"></script>
</head>
<body>

<div class="container">

    <?php
    if(isset($_SESSION['success']) && $_SESSION['success'] != ''){?>

        <div class="alert alert-success" role="alert">
            <?=$_SESSION['success']?>
        </div>

    <?php }
    $_SESSION['success'] = '';

    ?>

    <h1>История</h1>
    <a href="/kassir.php" class="btn btn-success">Назад</a>
    <a href="filtrs.php" class="btn btn-info">Филтр</a>
    <br>
    <br>
    <table class="table table-bordered">
        <tr>
            <th></th>
            <th>#Чек</th>
            <th>Дата</th>
            <th>Всего</th>
            <th>Кассир</th>
            <th></th>
            <th></th>
        </tr>

        <?php
        $count = 1;
        while($row = $view->fetch_array()) {?>
            <tr>
                <td><?php echo $count?></td>
                <td><?= $row['monor']?></td>
                <td><?= $row['tanggal_waktu']?></td>
                <td style="background: yellow; text-align: right"><?= number_format($row['total'], '0', ".", " ")?></td>
                <td><?= $row['nama']?></td>
                <td><?= $row['stol']?></td>

                <td>
                    <a href="unduh_struk.php?idtrx=<?=$row['id_transaksi'];?>" class="btn btn-primary">Просмотреть</a>
<!--                    <a href="unduh_struk.php?idtrx=--><?//=$row['id_transaksi'];?><!--" class="btn btn-primary">Скачать</a>-->
                </td>
            </tr>

            <?php $count = $count + 1;}?>

    </table>
</div>




</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
</html>

