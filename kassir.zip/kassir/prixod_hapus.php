<?php

include 'config.php';
session_start();
if(isset($_GET['id'])){
    $id = $_GET['id'];

    mysqli_query($dbconnect, "DELETE FROM `prixod` WHERE id_prixod='$id'");
    $_SESSION['success'] = 'Удалено!!!';
    header("Location:prixod.php");
}


?>

