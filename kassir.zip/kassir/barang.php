<?php
include 'config.php';
session_start();

include 'authcheck.php';

$view = $dbconnect->query("SELECT * FROM barang where qoldiq > 0");
//$view = $dbconnect->query("SELECT id_barang, nama, harga_k, harga, sum(jumlah) AS total_jumlah, kode_barang, sum(qoldiq) AS total_qoldiq, dates from barang GROUP BY nama ORDER BY `barang`.`id_barang` ASC ");








?>




<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

    <link rel="stylesheet" href="doc/css/bootstrap.css">
    <script src="doc/js/bootstrap.js"></script>
    <script src="doc/js/jquery.min.js"></script>
</head>
<body>

<div class="container-fluid">

    <?php
        if(isset($_SESSION['success']) && $_SESSION['success'] != ''){?>

            <div class="alert alert-success" role="alert">
            <?=$_SESSION['success']?>
            </div>

        <?php }
        $_SESSION['success'] = '';

        ?>

    <h1>Список товаров</h1>
    <a href="/index.php" class="fa fa-home btn btn-success"></a>
    <a href="/barang_add.php" class="btn btn-primary">Добавить данные</a>
    <a href="/barang_all.php" class="btn btn-danger" style="background-color: tomato">Все товары</a>
    <a href="/barang_nujno.php" class="btn btn-info">Законченный товары</a>
    <form action="barang_update.php" method="post" style="display: inline-block"><button name="passed" class="btn btn-danger">Обновить талицу</button></form>
    <a href="/excel/import.php" class="btn btn-success">Импорт из Excel</a>

    <form method="post" action="barang_export.php" style="display: inline-block"><input type="submit" name="submit" class="btn btn-warning" value="Экспорт в Excel" /></form>
    <a href="backup_sql_db.php" class="btn btn-danger">Экпорт в SQL</a>
    <br>
    <br>
    <table class="table table-bordered">
        <tr>
            <th>ID</th>
            <th>Товар</th>
            <th>Цена в приходе</th>
            <th>Цена в продаже</th>
            <th>Количество на складе</th>
            <th>Остатка</th>
            <th>Дата</th>
            <th>Штрих код</th>
            <th>Действии</th>
        </tr>

<?php                    $count = 1;
                        while($row = $view->fetch_array()) {?>
        <tr>
            <td><?php echo $count?></td>
            <td><?= $row['nama']?></td>
            <td align="right" style="background: yellowgreen"><?= number_format($row['harga_k'], '0', '.', ' ');?></td>
            <td align="right" style="background: yellow; font-size: 20px;"><?= number_format($row['harga'], '0', '.', ' ');?></td>
            <td style="background: blueviolet; color: white; text-align: center; font-size: 20px;"><?= $row['jumlah']?></td>
<!--            <td style="background: blueviolet; color: white; text-align: center; font-size: 20px;">--><?//= $row['total_jumlah']?><!--</td>-->
            <td style="font-size: 20px; background: darkseagreen; text-align: center"><?= $row['qoldiq']?></td>
<!--            <td style="font-size: 20px; background: darkseagreen; text-align: center">--><?//= $row['total_qoldiq']?><!--</td>-->
            <td><?= $row['dates']?></td>
            <td><?= $row['kode_barang']?></td>
            <td><a href="/barang_edit.php?id=<?=$row['id_barang']?>">Редактировать</a> |
                <a href="/barang_hapus.php?id=<?=$row['id_barang']?>" onclick="return confirm('Вы уверены?')">Удалить</a>

            </td>
        </tr>

<?php $count = $count + 1;}?>

    </table>
</div>




</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
</html>

