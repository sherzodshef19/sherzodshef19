<?php
include 'config.php';
session_start();


$view = $dbconnect->query("SELECT transaksi_detall.*, transaksi.*, barang.nama, barang.id_barang, barang.qoldiq FROM `transaksi_detall`, `transaksi`, `barang` WHERE transaksi_detall.id_transaksi = transaksi.id_transaksi AND transaksi_detall.id_barang = barang.id_barang ORDER BY `transaksi`.`tanggal_waktu` DESC");
//$view = $dbconnect->query("SELECT transaksi_detall.*, transaksi.*, barang.nama, barang.id_barang, sum(barang.qoldiq) AS total_qoldiq sum(barang.jumlah) AS total_qoldiq FROM `transaksi_detall`, `transaksi`, `barang` WHERE transaksi_detall.id_transaksi = transaksi.id_transaksi AND transaksi_detall.id_barang = barang.id_barang ORDER BY `transaksi`.`tanggal_waktu` DESC");
$sum = 0;



?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
<!--    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->
<!--    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">-->
<!--    <link rel="stylesheet" href="doc/css/bootstrap.css">-->



    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
</head>
<body>

<div class="container-fluid">

    <?php
    if(isset($_SESSION['success']) && $_SESSION['success'] != ''){?>

        <div class="alert alert-success" role="alert">
            <?=$_SESSION['success']?>
        </div>

    <?php }
    $_SESSION['success'] = '';

    ?>

    <h1>Список товаров</h1>
    <a href="/index.php" class="fa fa-home btn btn-success" style="display:inline-block;"></a>
    <form method="post" action="export_excel.php" style="display: inline-block">
        <input type="submit" name="submit" class="btn btn-primary" value="Export" />
    </form>
    <div style="display: inline-block">
        <input type="text" name="from_date" id="from_date" class="form-control dateFilter" placeholder="From Date" />
    </div>
    <div style="display: inline-block">
        <input type="text" name="to_date" id="to_date" class="form-control dateFilter" placeholder="To Date" />
    </div>
    <div style="display: inline-block">
        <input type="button" name="search" id="btn_search" value="Search" class="btn btn-info" />
    </div>
    <br>
    <br>
    <div id="purchase_order">
    <table class="table table-bordered">
        <tr>
            <th>ID</th>
            <th>Товар</th>
            <th>Дата</th>
            <th>штук</th>
            <th>Цена в продаже</th>
            <th>Остатка</th>
            <th>Итого</th>
            <th>Какой</th>
            <th>Сотрудник</th>
            <th>Действие</th>
        </tr>

        <?php                    $count = 1;
        while($row = $view->fetch_array()) {?>
            <tr>
                <td><?php echo $count?></td>
                <td><?= $row['nama']?></td>
                <td><?= $row['tanggal_waktu']?></td>
                <td ><?= $row['qrt']?></td>
                <td align="right" style="background: yellow; font-size: 20px;"><?= number_format($row['harga'], '0', '.', ' ');?></td>
                <td style="font-size: 20px; background: darkseagreen; text-align: center"><?= $row['qoldiq']?></td>
                <td><?= $row['total']?></td>
                <td><?= $row['stol']?></td>
                <td><?= $row['xodim_name']?></td>
                <td><a href="history_hapus.php?id=<?=$row['id_transaksi_detail']?>" onclick="return confirm('Вы уверены?')">Удалить</a></td>



            </tr>

            <?php $count = $count + 1;}?>

    </table>
    </div>
</div>




</body>

<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>-->
<!--<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>-->
<!--<script src="doc/js/bootstrap.js"></script>-->
<!--<script src="doc/js/jquery.min.js"></script>-->
<script>
    $(document).ready(function () {

        $('.dateFilter').datepicker({
            dateFormat: "yy-mm-dd "
        });

        $('#btn_search').click(function () {
            var from_date = $('#from_date').val();
            var to_date = $('#to_date').val();
            if (from_date != '' && to_date != '') {
                $.ajax({
                    url: "action.php",
                    method: "POST",
                    data: { from_date: from_date, to_date: to_date },
                    success: function (data) {
                        $('#purchase_order').html(data);
                    }
                });
            }
            else {
                alert("Please Select the Date");
            }
        });
    });
</script>

</html>

