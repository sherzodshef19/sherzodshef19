<?php
include 'config.php';
//session_start();
//include 'authcheck.php';


if(isset($_POST['simpan'])){
    $kode_prixod = $_POST['kode_prixod'];
    $qty_prixod = $_POST['qty_prixod'];
    $nama_prixod = $_POST['nama_prixod'];
    $harga_k_prixod = $_POST['harga_k_prixod'];
    $harga_prixod = $_POST['harga_prixod'];
    $prixod_date = $_POST['prixod_date'];

    mysqli_query($dbconnect, "INSERT INTO `prixod` (`id_prixod`, `nama_prixod`, `harga_k_prixod`, `harga_prixod`, `qty_prixod`, `prixod_date`, `kode_prixod`) VALUE ('', '$nama_prixod', '$harga_k_prixod', '$harga_prixod', '$qty_prixod', '$prixod_date', '$kode_prixod')");
    mysqli_query($dbconnect, "INSERT INTO `barang` (`id_barang`, `nama`, `harga_k`, `harga`, `jumlah`, `dates`, `kode_barang`) VALUE ('', '$nama_prixod', '$harga_k_prixod', '$harga_prixod', '$qty_prixod', '$prixod_date', '$kode_prixod')");
    $_SESSION['success'] = 'Товар добавлено!';

    header("location:prixod.php");
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <link rel="stylesheet" href="doc/css/bootstrap.css">
    <script src="doc/js/bootstrap.js"></script>
    <script src="doc/js/jquery.min.js"></script>
</head>
<body>


<div class="container">
    <h1>Добавить товар</h1>

    <form method="post">

        <div class="form-group">
            <label>Штрих код</label>
            <input type="text" name="kode_prixod" class="form-control" placeholder="Штрих">
        </div>

        
        <div class="form-group">
            <label>Название товара</label>
            <input type="text" name="nama_prixod" class="form-control" placeholder="Товар">

        </div>


        <div class="form-group">
            <label>Цена в приходе</label>
            <input type="number" name="harga_k_prixod" class="form-control" placeholder="Цена в приходе">
        </div>

        <div class="form-group">
            <label>Цена в продаже</label>
            <input type="number" name="harga_prixod" class="form-control" placeholder="Цена в продаже">
        </div>

        <div class="form-group">
            <label>Кол-во</label>
            <input type="number" name="qty_prixod" class="form-control" placeholder="Кол-во">
        </div>

        <div class="form-group">
            <label>Дата</label>
            <input type="datetime-local" name="prixod_date" class="form-control" placeholder="Дата">
        </div>

        <input type="submit" name="simpan" value="Добавить" class="btn btn-primary">
        <a href="barang.php" class="btn btn-warning">Вернуть</a>



    </form>
</div>



</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $(window).keydown(function(event){
            if(event.keyCode == 13) {
                event.preventDefault();
                return false;
            }
        });
    });
</script>
</html>

