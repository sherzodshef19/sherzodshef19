<?php
include 'config.php';
session_start();

//print_r($_SESSION);
include 'authcheck.php';

$view = $dbconnect->query("SELECT u.*,r.nama as nama_role FROM user as u INNER JOIN role as r ON u.role_id=r.id_role");
//print_r($view->fetch_array());
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>User</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <link rel="stylesheet" href="doc/css/bootstrap.css">
    <script src="doc/js/bootstrap.js"></script>
    <script src="doc/js/jquery.min.js"></script>
</head>
<body>


<div class="container">

    <?php
    if(isset($_SESSION['success']) && $_SESSION['success'] != ''){?>

        <div class="alert alert-success" role="alert">
            <?=$_SESSION['success']?>
        </div>

    <?php }
    $_SESSION['success'] = '';

    ?>

    <h1>Список пользователей</h1>
    <a href="/index.php" class="fa fa-home btn btn-success"></a>
    <a href="/user_add.php" class="btn btn-primary">Добавить данные</a>
    <br>
    <br>
    <table class="table table-bordered">
        <tr>
            <th>ID User</th>
            <th>Имя</th>
            <th>Username</th>
            <th>Password</th>
            <th>Роль</th>
            <th>Действии</th>
        </tr>

        <?php
        $count = 1;
        while($row = $view->fetch_array()) {?>
            <tr>
                <td><?php echo $count?></td>
                <td><?= $row['nama']?></td>
                <td><?= $row['username']?></td>
                <td><?= $row['password']?></td>
                <td><?= $row['nama_role']?></td>
                <td>
                    <a href="/user_edit.php?id=<?=$row['id_user']?>">Редактировать</a> |
                    <a href="/user_hapus.php?id=<?=$row['id_user']?>" onclick="return confirm('Вы уверены?')">Удалить</a>
                </td>
            </tr>

            <?php $count = $count + 1;}?>

    </table>
</div>





</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
</html>

