<?php
include 'config.php';
session_start();
include 'authcheck.php';
// db connection

if(isset($_POST['passed'])){

    $allowed = mysqli_query($dbconnect,"UPDATE barang
SET qoldiq = (SELECT t1.remainds
              FROM (SELECT barang.id_barang, (barang.jumlah - IFNULL(transaksi_detall.sold, 0)) as remainds
                    FROM barang
                             LEFT JOIN (
                        SELECT id_barang, SUM(qrt) as sold FROM transaksi_detall GROUP BY id_barang) as transaksi_detall
                                       ON barang.id_barang = transaksi_detall.id_barang) as t1
              WHERE t1.id_barang = barang.id_barang)
WHERE barang.id_barang IS NOT NULL;");



}

header("location:barang.php");

?>