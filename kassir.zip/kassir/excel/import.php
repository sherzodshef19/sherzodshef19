<?php 
$hostname = "192.168.1.8";
$username = "root";
$password = "";
$database = "kassir";
session_start();


$conn = mysql_connect("$hostname","$username","$password") or die(mysql_error());
mysql_select_db("$database", $conn);


if(isset($_POST["submit"]))
{
	$file = $_FILES['file']['tmp_name'];
	$fc = iconv('', 'UTF-8', file_get_contents($file)); 
	$handle = fopen($file, "r");
	$handle=fopen("php://memory", "rw"); 
    fwrite($handle, $fc); 
    fseek($handle, 0); 
	$c = 0;
	while(($filesop = fgetcsv($handle, 1000, ";")) !== false)
	{
		$nama = $filesop[0];
		$harga_k = $filesop[1];
		$harga = $filesop[2];
		$jumlah = $filesop[3];
		
		$sql = mysql_query("INSERT INTO barang (nama, harga_k, harga, jumlah) VALUES ('$nama','$harga_k', '$harga', '$jumlah')");
	}
	
		if($sql){
//			echo "Ваша база данных успешно импортирована";
            $_SESSION['success'] = 'Ваша база данных успешно импортирована!';
            header("location:../barang.php");
		}else{
			echo "Извини! Есть какая-то проблема.";
		}
}

$filesop[number_of_column];

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Import from Excel</title>
    <link rel="stylesheet" href="../doc/css/bootstrap.css">
    <link rel="stylesheet" href="../doc/js/bootstrap.js">
    <link rel="stylesheet" href="../doc/js/jquery.min.js">
</head>
<body>
<div class="container">
<div class="row">
    <div class="col-md-4 col-md-offset-3" style="margin-top:20%;">
        <h3>Импортировать из Excel cvs</h3>
        <form name="import" method="post" enctype="multipart/form-data" class="form-control">
            <input type="file" name="file" /><br />
            <input type="submit" class="btn btn-success" name="submit" value="Загрузить" />
        </form>


    </div>
</div>
</div>


</body>
</html>
