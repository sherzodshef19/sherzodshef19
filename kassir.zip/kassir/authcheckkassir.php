<?php

session_start();

if(isset($_SESSION['userid']))
{
    if($_SESSION['role_id']==1)
    {
        header("location:index.php");
    }
}else{
    $_SESSION['error'] = 'Ошибка!';
    header("location:login.php");
}

?>