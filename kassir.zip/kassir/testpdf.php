<?php

require_once 'library/dompdf/autoload.inc.php';


use Dompdf\Dompdf;


$dompdf = new Dompdf();

$dompdf->loadHtml("");


$dompdf->setPaper('A4', 'landcape');

$dompdf->render();

$dompdf->stream();


?>

