<?php
include 'config.php';
session_start();
include 'authcheckkassir.php';

if(isset($_POST['kode_barang']))
{



    $kode_barang = $_POST['kode_barang'];
    $qty = 1;
//    $data = mysqli_query($dbconnect, "SELECT * FROM barang WHERE kode_barang='$kode_barang' ");
    $data = mysqli_query($dbconnect, "SELECT id_barang, nama, harga_k, harga, sum(jumlah) AS total_jumlah, kode_barang, sum(qoldiq) AS total_qoldiq, dates from barang WHERE kode_barang='$kode_barang' and qoldiq > 0 GROUP BY nama");

    $b = mysqli_fetch_assoc($data);

    $barang = [
        'id' => $b['id_barang'],
        'nama' => $b['nama'],
        'harga' => $b['harga'],
        'harga_d' => $b['harga_d'],
        'qty' => $qty,
        'qoldiq' => $b['total_qoldiq'],
    ];

    $_SESSION['cart'][]=$barang;

//    krsort($_SESSION['cart']);


    $allowed = mysqli_query($dbconnect,"UPDATE barang
SET qoldiq = (SELECT t1.remainds
              FROM (SELECT barang.id_barang, (barang.jumlah - IFNULL(transaksi_detall.sold, 0)) as remainds
                    FROM barang
                             LEFT JOIN (
                        SELECT id_barang, SUM(qrt) as sold FROM transaksi_detall GROUP BY id_barang) as transaksi_detall
                                       ON barang.id_barang = transaksi_detall.id_barang) as t1
              WHERE t1.id_barang = barang.id_barang)
WHERE barang.id_barang IS NOT NULL;");


    header("Location:kassir.php");
}


?>
